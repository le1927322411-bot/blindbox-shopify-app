import './config.js';
import http from 'node:http';
import { URL } from 'node:url';
import { exchangeCodeForToken, redirectToShopifyInstall } from './oauth.js';
import { completeDailyCheckin, consumeOAuthState, grantCredit, getCredit, releaseDailyCheckin, reserveDailyCheckin, saveResult } from './store.js';
import { validShopDomain, verifyAppProxySignature, verifyDevProxyToken, verifyOAuthHmac, verifyWebhookHmac } from './security.js';
import { createPrizeOrder, findCustomerEmailById, findOrderByNameAndEmail, registerOrdersPaidWebhook, setOrderMetafields, tagOrder } from './shopify.js';
import { adjustGlowPointsByEmail } from './glow.js';

const port = Number(process.env.PORT || 8787);

function json(res, status, body) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store'
  });
  res.end(JSON.stringify(body));
}

function allowedCorsOrigin(req) {
  const origin = String(req.headers.origin || '').replace(/\/$/, '');
  const referer = String(req.headers.referer || '');
  const allowed = (process.env.PUBLIC_CORS_ORIGINS || 'https://jadeabyss.com,https://www.jadeabyss.com,https://ht60wm-np.myshopify.com')
    .split(',')
    .map((value) => value.trim().replace(/\/$/, ''))
    .filter(Boolean);
  if (origin && allowed.includes(origin)) return origin;
  if (!origin && allowed.some((value) => referer.startsWith(`${value}/`) || referer === value)) {
    return allowed.find((value) => referer.startsWith(`${value}/`) || referer === value);
  }
  return '';
}

function applyCors(req, res) {
  const origin = allowedCorsOrigin(req);
  if (!origin) return false;
  res.setHeader('access-control-allow-origin', origin);
  res.setHeader('access-control-allow-methods', 'GET,POST,OPTIONS');
  res.setHeader('access-control-allow-headers', 'Accept,Content-Type');
  res.setHeader('access-control-max-age', '600');
  return true;
}

function html(res, status, body) {
  res.writeHead(status, {
    'content-type': 'text/html; charset=utf-8',
    'cache-control': 'no-store'
  });
  res.end(body);
}

async function readRawBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks);
}

function countCashBlindboxCredits(order) {
  const keyword = process.env.CASH_PRODUCT_TITLE_KEYWORD || '现金盲盒';
  const productId = process.env.CASH_PRODUCT_ID;
  const variantId = process.env.CASH_VARIANT_ID;
  return (order.line_items || []).reduce((total, item) => {
    const isMatch = (productId && String(item.product_id) === String(productId))
      || (variantId && String(item.variant_id) === String(variantId))
      || (keyword && String(item.title || '').includes(keyword));
    return total + (isMatch ? Math.max(1, Number(item.quantity || 1)) : 0);
  }, 0);
}

function appProxyAuthorized(req, url) {
  return verifyAppProxySignature(url.searchParams, process.env.SHOPIFY_API_SECRET)
    || verifyDevProxyToken(req, process.env.DEV_PROXY_TOKEN);
}

function storefrontAuthorized(req) {
  return Boolean(allowedCorsOrigin(req))
    || verifyDevProxyToken(req, process.env.DEV_PROXY_TOKEN);
}

async function handleOrdersPaid(req, res) {
  const rawBody = await readRawBody(req);
  const isValid = verifyWebhookHmac(
    rawBody,
    req.headers['x-shopify-hmac-sha256'],
    process.env.SHOPIFY_API_SECRET
  );
  if (!isValid) return json(res, 401, { ok: false, error: 'invalid_webhook_hmac' });

  const order = JSON.parse(rawBody.toString('utf8'));
  const credits = countCashBlindboxCredits(order);
  if (credits <= 0) return json(res, 200, { ok: true, skipped: 'not_cash_blindbox' });

  const credit = await grantCredit({
    orderId: `gid://shopify/Order/${order.id}`,
    orderName: order.name,
    email: order.email || order.contact_email,
    credits
  });

  return json(res, 200, { ok: true, credit });
}

async function handleAuth(req, res, url) {
  const shop = url.searchParams.get('shop') || process.env.SHOPIFY_SHOP_DOMAIN;
  if (!validShopDomain(shop)) return json(res, 400, { ok: false, error: 'invalid_shop' });

  const hasHmac = url.searchParams.has('hmac');
  if (hasHmac && !verifyOAuthHmac(url.searchParams, process.env.SHOPIFY_API_SECRET)) {
    return json(res, 401, { ok: false, error: 'invalid_oauth_hmac' });
  }

  return redirectToShopifyInstall(res, req, shop);
}

async function handleAuthCallback(req, res, url) {
  const shop = url.searchParams.get('shop');
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  if (!validShopDomain(shop) || !code || !state) {
    return json(res, 400, { ok: false, error: 'missing_oauth_callback_params' });
  }
  if (!verifyOAuthHmac(url.searchParams, process.env.SHOPIFY_API_SECRET)) {
    return json(res, 401, { ok: false, error: 'invalid_oauth_hmac' });
  }
  if (!(await consumeOAuthState(state, shop))) {
    return json(res, 401, { ok: false, error: 'invalid_oauth_state' });
  }

  const token = await exchangeCodeForToken(shop, code);
  let webhook = null;
  const publicUrl = process.env.PUBLIC_APP_URL || process.env.APP_URL;
  if (publicUrl && !publicUrl.includes('example.com')) {
    webhook = await registerOrdersPaidWebhook({
      shop,
      uri: `${publicUrl.replace(/\/$/, '')}/webhooks/orders-paid`
    });
  }
  return html(res, 200, `
    <!doctype html>
    <meta charset="utf-8">
    <title>Blindbox App Installed</title>
    <body style="font-family: system-ui, sans-serif; padding: 32px;">
      <h1>Blindbox Draw Backend 已安装</h1>
      <p>店铺：${shop}</p>
      <p>权限：${token.scope || ''}</p>
      <p>付款 Webhook：${webhook ? '已创建' : '未创建，请先把 PUBLIC_APP_URL 换成真实域名后重新安装或手动创建'}</p>
      <p>现在可以关闭此页。下一步是部署后端并把 App Proxy / Webhook URL 改成真实域名。</p>
    </body>
  `);
}

async function handleVerify(req, res, url) {
  if (!appProxyAuthorized(req, url)) return json(res, 401, { ok: false, error: 'invalid_app_proxy_signature' });
  const orderName = url.searchParams.get('order');
  const email = url.searchParams.get('email');
  const credit = await getCredit(orderName, email);

  if (!credit || Number(credit.credits || 0) <= 0) {
    return json(res, 404, { ok: false, error: 'no_available_credit' });
  }

  return json(res, 200, {
    ok: true,
    orderName: credit.orderName,
    email: credit.email,
    credits: credit.credits
  });
}

async function handleConfirm(req, res, url) {
  if (!appProxyAuthorized(req, url)) return json(res, 401, { ok: false, error: 'invalid_app_proxy_signature' });
  const payload = JSON.parse((await readRawBody(req)).toString('utf8') || '{}');
  const { orderName, email, action, result } = payload;
  if (!orderName || !email || !action || !result) {
    return json(res, 400, { ok: false, error: 'missing_required_fields' });
  }

  const saved = await saveResult({ orderName, email, action, result });
  if (!saved.ok) return json(res, 409, saved);

  const order = await findOrderByNameAndEmail(orderName, email);
  if (!order || order.displayFinancialStatus !== 'PAID') {
    return json(res, 409, { ok: false, error: 'paid_order_not_found', savedLocally: true });
  }

  await tagOrder(order.id, ['blindbox-result', action === 'ship' ? 'blindbox-ship' : 'blindbox-decompose']);
  await setOrderMetafields(order.id, {
    draw_action: action,
    prize_tier: result.tier || '',
    prize_title: result.productTitle || result.title || '',
    prize_variant_id: result.variantId || '',
    prize_serial: result.serial || '',
    result_json: JSON.stringify(result).slice(0, 255)
  });

  let prizeOrder = null;
  if (process.env.CREATE_PRIZE_ORDER === 'true' && action === 'ship') {
    prizeOrder = await createPrizeOrder({ email, result, originalOrderName: orderName });
  }

  let glowPoints = null;
  if (action === 'decompose') {
    const points = Math.max(0, Math.trunc(Number(result.decomposablePoints || result.points || 0)));
    if (points > 0) {
      glowPoints = await adjustGlowPointsByEmail({
        email,
        pointsChange: points,
        customName: `Blind box decompose +${points} points`
      });
    }
  }

  return json(res, 200, {
    ok: true,
    message: 'blindbox_result_saved',
    orderId: order.id,
    prizeOrder,
    glowPoints
  });
}

async function handleGlowPoints(req, res, url) {
  if (!appProxyAuthorized(req, url) && !(url.pathname === '/public/glow-points' && storefrontAuthorized(req))) {
    return json(res, 401, { ok: false, error: 'invalid_app_proxy_signature' });
  }
  const payload = req.method === 'GET'
    ? Object.fromEntries(url.searchParams.entries())
    : JSON.parse((await readRawBody(req)).toString('utf8') || '{}');
  const email = await resolveCustomerEmail({ url, payload });
  const pointsChange = normalizePointsChange(payload);
  if (!email) return json(res, 400, { ok: false, error: 'missing_customer_email' });
  if (!pointsChange) return json(res, 400, { ok: false, error: 'missing_points_change' });
  if (Math.abs(pointsChange) > Number(process.env.GLOW_MAX_POINTS_ADJUSTMENT || 5000)) {
    return json(res, 400, { ok: false, error: 'points_change_too_large' });
  }
  const result = await adjustGlowPointsByEmail({
    email,
    pointsChange,
    customName: payload.customName || payload.description || (pointsChange > 0 ? 'Blind box points credited' : 'Blind box points spent')
  });
  return json(res, result.ok ? 200 : 404, result);
}

function normalizePointsChange(payload) {
  return Math.trunc(Number(
    payload?.pointsChange
    ?? payload?.points_change
    ?? payload?.points
    ?? payload?.amount
    ?? 0
  ));
}

function localDateString(date = new Date()) {
  const offsetMinutes = Number(process.env.DAILY_CHECKIN_TZ_OFFSET_MINUTES || 480);
  const shifted = new Date(date.getTime() + offsetMinutes * 60 * 1000);
  return shifted.toISOString().slice(0, 10);
}

async function resolveCustomerEmail({ url, payload }) {
  const payloadEmail = String(
    payload?.email
    || payload?.customerEmail
    || payload?.customer_email
    || payload?.contact_email
    || payload?.customer?.email
    || ''
  ).trim().toLowerCase();
  if (payloadEmail) return payloadEmail;

  const customerId = url.searchParams.get('logged_in_customer_id');
  if (!customerId) return '';

  try {
    return await findCustomerEmailById(customerId);
  } catch (error) {
    if (String(error.message || '').includes('read_customers')) {
      throw new Error('missing_read_customers_scope_reinstall_app');
    }
    throw error;
  }
}

async function handleDailyCheckin(req, res, url) {
  if (!appProxyAuthorized(req, url) && !(url.pathname === '/public/daily-checkin' && storefrontAuthorized(req))) {
    return json(res, 401, { ok: false, error: 'invalid_app_proxy_signature' });
  }
  const payload = req.method === 'GET'
    ? Object.fromEntries(url.searchParams.entries())
    : JSON.parse((await readRawBody(req)).toString('utf8') || '{}');
  const email = await resolveCustomerEmail({ url, payload });
  const points = Math.max(1, Math.trunc(Number(process.env.DAILY_CHECKIN_POINTS || 50)));
  if (!email) return json(res, 400, { ok: false, error: 'missing_customer_email' });

  const date = localDateString();
  const reserved = await reserveDailyCheckin({ email, date, points });
  if (!reserved.ok) {
    return json(res, 409, { ok: false, error: reserved.error, date, points });
  }

  try {
    const glowPoints = await adjustGlowPointsByEmail({
      email,
      pointsChange: points,
      customName: `Daily check-in +${points} points`
    });
    const checkin = await completeDailyCheckin(reserved.key, { glowPoints });
    return json(res, 200, { ok: true, date, points, checkin, glowPoints });
  } catch (error) {
    await releaseDailyCheckin(reserved.key, { error: error.message });
    throw error;
  }
}

async function route(req, res) {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    applyCors(req, res);
    if (req.method === 'OPTIONS') {
      res.writeHead(204, { 'cache-control': 'no-store' });
      return res.end();
    }
    if (req.method === 'GET' && url.pathname === '/health') {
      return json(res, 200, { ok: true });
    }
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/auth')) {
      return handleAuth(req, res, url);
    }
    if (req.method === 'GET' && url.pathname === '/auth/callback') {
      return handleAuthCallback(req, res, url);
    }
    if (req.method === 'POST' && url.pathname === '/webhooks/orders-paid') {
      return handleOrdersPaid(req, res);
    }
    if (req.method === 'GET' && url.pathname === '/app-proxy/verify') {
      return handleVerify(req, res, url);
    }
    if (req.method === 'POST' && url.pathname === '/app-proxy/confirm-shipping') {
      return handleConfirm(req, res, url);
    }
    if ((req.method === 'GET' || req.method === 'POST') && (url.pathname === '/app-proxy/glow-points' || url.pathname === '/app-proxy/smile-points')) {
      return handleGlowPoints(req, res, url);
    }
    if ((req.method === 'GET' || req.method === 'POST') && url.pathname === '/app-proxy/daily-checkin') {
      return handleDailyCheckin(req, res, url);
    }
    if ((req.method === 'GET' || req.method === 'POST') && url.pathname === '/public/glow-points') {
      return handleGlowPoints(req, res, url);
    }
    if ((req.method === 'GET' || req.method === 'POST') && url.pathname === '/public/daily-checkin') {
      return handleDailyCheckin(req, res, url);
    }
    return json(res, 404, { ok: false, error: 'not_found' });
  } catch (error) {
    console.error(error);
    return json(res, 500, { ok: false, error: error.message });
  }
}

http.createServer(route).listen(port, () => {
  console.log(`Blindbox Shopify app listening on http://localhost:${port}`);
});
