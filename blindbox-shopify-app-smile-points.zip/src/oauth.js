import crypto from 'node:crypto';
import { saveOAuthState, saveShopSession } from './store.js';

export function publicAppUrl(req) {
  const configured = process.env.PUBLIC_APP_URL || process.env.APP_URL;
  if (configured) return configured.replace(/\/$/, '');
  const proto = req.headers['x-forwarded-proto'] || 'http';
  return `${proto}://${req.headers.host}`;
}

export async function redirectToShopifyInstall(res, req, shop) {
  const clientId = process.env.SHOPIFY_CLIENT_ID || process.env.SHOPIFY_API_KEY;
  if (!clientId) throw new Error('Missing SHOPIFY_CLIENT_ID');

  const scopes = 'read_orders,write_orders,read_customers';
  const state = crypto.randomBytes(16).toString('hex');
  await saveOAuthState(state, shop);

  const redirectUri = `${publicAppUrl(req)}/auth/callback`;
  const params = new URLSearchParams({
    client_id: clientId,
    scope: scopes,
    redirect_uri: redirectUri,
    state
  });

  res.writeHead(302, { location: `https://${shop}/admin/oauth/authorize?${params.toString()}` });
  res.end();
}

export async function exchangeCodeForToken(shop, code) {
  const clientId = process.env.SHOPIFY_CLIENT_ID || process.env.SHOPIFY_API_KEY;
  const clientSecret = process.env.SHOPIFY_API_SECRET;
  const response = await fetch(`https://${shop}/admin/oauth/access_token`, {
    method: 'POST',
    headers: {
      'content-type': 'application/json',
      accept: 'application/json'
    },
    body: JSON.stringify({
      client_id: clientId,
      client_secret: clientSecret,
      code
    })
  });

  const body = await response.json();
  if (!response.ok || !body.access_token) {
    throw new Error(`Shopify OAuth token exchange failed: ${JSON.stringify(body)}`);
  }

  await saveShopSession({ shop, accessToken: body.access_token, scope: body.scope });
  return body;
}
