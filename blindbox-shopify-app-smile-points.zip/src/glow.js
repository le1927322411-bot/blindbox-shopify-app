const glowApiBase = process.env.GLOW_API_BASE_URL || 'https://www.glowloyalty.com/api/v1';

function glowCredentials() {
  const apiKey = process.env.GLOW_API_KEY;
  const apiSecret = process.env.GLOW_API_SECRET;
  if (!apiKey || !apiSecret) throw new Error('Missing GLOW_API_KEY or GLOW_API_SECRET');
  return { apiKey, apiSecret };
}

async function glowRequest(path, formFields) {
  const { apiKey, apiSecret } = glowCredentials();
  const body = new URLSearchParams();
  for (const [key, value] of Object.entries(formFields || {})) {
    if (value !== undefined && value !== null && value !== '') body.set(key, String(value));
  }

  const response = await fetch(`${glowApiBase}${path}`, {
    method: 'POST',
    headers: {
      'api-key': apiKey,
      'api-secret': apiSecret,
      'Accept': 'application/json',
      'Content-Type': 'application/x-www-form-urlencoded'
    },
    body
  });
  const text = await response.text();
  let data = {};
  try {
    data = text ? JSON.parse(text) : {};
  } catch {
    data = { raw: text };
  }
  if (!response.ok) {
    const message = data?.message || data?.error || data?.raw || `HTTP ${response.status}`;
    throw new Error(`Glow API error ${response.status}: ${message}`);
  }
  return data;
}

export async function adjustGlowPointsByEmail({ email, pointsChange, customName, customImage }) {
  const cleanEmail = String(email || '').trim().toLowerCase();
  const points = Math.trunc(Number(pointsChange || 0));
  if (!cleanEmail) return { ok: false, error: 'missing_customer_email' };
  if (!points) return { ok: false, error: 'invalid_points_change' };

  let data;
  try {
    data = await glowRequest('/adjust-points', {
      email: cleanEmail,
      points,
      custom_name: customName || 'Jade Abyss Points',
      custom_image: customImage || process.env.GLOW_CUSTOM_IMAGE_URL || ''
    });
  } catch (error) {
    if (/member not found/i.test(String(error.message || ''))) {
      return {
        ok: false,
        email: cleanEmail,
        pointsChange: points,
        error: 'glow_member_not_found',
        message: 'Glow member not found'
      };
    }
    throw error;
  }

  return {
    ok: true,
    email: cleanEmail,
    pointsChange: points,
    glow: data
  };
}
