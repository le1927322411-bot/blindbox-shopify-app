import crypto from 'node:crypto';

function timingSafeEqualString(a, b) {
  const left = Buffer.from(String(a || ''), 'utf8');
  const right = Buffer.from(String(b || ''), 'utf8');
  if (left.length !== right.length) return false;
  return crypto.timingSafeEqual(left, right);
}

export function verifyWebhookHmac(rawBody, headerHmac, secret) {
  if (!secret || !headerHmac) return false;
  const digest = crypto.createHmac('sha256', secret).update(rawBody).digest('base64');
  return timingSafeEqualString(digest, headerHmac);
}

export function verifyAppProxySignature(searchParams, secret) {
  if (!secret) return false;
  const signature = searchParams.get('signature');
  if (!signature) return false;

  const pairs = [];
  for (const [key, value] of searchParams.entries()) {
    if (key === 'signature') continue;
    pairs.push(`${key}=${value}`);
  }
  pairs.sort();

  const message = pairs.join('');
  const digest = crypto.createHmac('sha256', secret).update(message).digest('hex');
  return timingSafeEqualString(digest, signature);
}

export function verifyDevProxyToken(request, expectedToken) {
  if (!expectedToken) return false;
  const token = request.headers?.['x-blindbox-dev-token'] || request.headers?.['X-Blindbox-Dev-Token'] || '';
  return timingSafeEqualString(token, expectedToken);
}

export function verifyOAuthHmac(searchParams, secret) {
  if (!secret) return false;
  const hmac = searchParams.get('hmac');
  if (!hmac) return false;

  const pairs = [];
  for (const [key, value] of searchParams.entries()) {
    if (key === 'hmac' || key === 'signature') continue;
    pairs.push(`${key}=${value}`);
  }
  pairs.sort();

  const digest = crypto.createHmac('sha256', secret).update(pairs.join('&')).digest('hex');
  return timingSafeEqualString(digest, hmac);
}

export function validShopDomain(shop) {
  return /^[a-zA-Z0-9][a-zA-Z0-9-]*\.myshopify\.com$/.test(String(shop || ''));
}
