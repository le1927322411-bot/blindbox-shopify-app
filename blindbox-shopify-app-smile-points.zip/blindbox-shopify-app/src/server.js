import './config.js';
import http from 'node:http';
import { URL } from 'node:url';
import { exchangeCodeForToken, redirectToShopifyInstall } from './oauth.js';
import { consumeOAuthState, grantCredit, getCredit, saveResult } from './store.js';
import { validShopDomain, verifyAppProxySignature, verifyDevProxyToken, verifyOAuthHmac, verifyWebhookHmac } from './security.js';
import { createPrizeOrder, findOrderByNameAndEmail, registerOrdersPaidWebhook, setOrderMetafields, tagOrder } from './shopify.js';
import { adjustSmilePointsByEmail } from './smile.js';

const port = Number(process.env.PORT || 8787);

function json(res, status, body) {
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'cache-control': 'no-store'
  });
  res.end(JSON.stringify(body));
}

function html(res, status, body) {
  res.writeHead(status, {
    'content-type': 'text/html; charset=utf-8',
    'cache-control': 'no-store'
  });
  res.end(body);
}

async function readRawBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks);
}

function matchesCashBlindbox(order) {
  const keyword = process.env.CASH_PRODUCT_TITLE_KEYWORD || '现金盲盒';
  const productId = process.env.CASH_PRODUCT_ID;
  const variantId = process.env.CASH_VARIANT_ID;
  return (order.line_items || []).some((item) => {
    if (productId && String(item.product_id) === String(productId)) return true;
    if (variantId && String(item.variant_id) === String(variantId)) return true;
    return keyword && String(item.title || '').includes(keyword);
  });
}

function appProxyAuthorized(req, url) {
  return verifyAppProxySignature(url.searchParams, process.env.SHOPIFY_API_SECRET)
    || verifyDevProxyToken(req, process.env.DEV_PROXY_TOKEN);
}

async function handleOrdersPaid(req, res) {
  const rawBody = await readRawBody(req);
  const isValid = verifyWebhookHmac(
    rawBody,
    req.headers['x-shopify-hmac-sha256'],
    process.env.SHOPIFY_API_SECRET
  );
  if (!isValid) return json(res, 401, { ok: false, error: 'invalid_webhook_hmac' });

  const order = JSON.parse(rawBody.toString('utf8'));
  if (!matchesCashBlindbox(order)) return json(res, 200, { ok: true, skipped: 'not_cash_blindbox' });

  const credit = await grantCredit({
    orderId: `gid://shopify/Order/${order.id}`,
    orderName: order.name,
    email: order.email || order.contact_email,
    credits: 1
  });

  return json(res, 200, { ok: true, credit });
}

async function handleAuth(req, res, url) {
  const shop = url.searchParams.get('shop') || process.env.SHOPIFY_SHOP_DOMAIN;
  if (!validShopDomain(shop)) return json(res, 400, { ok: false, error: 'invalid_shop' });

  const hasHmac = url.searchParams.has('hmac');
  if (hasHmac && !verifyOAuthHmac(url.searchParams, process.env.SHOPIFY_API_SECRET)) {
    return json(res, 401, { ok: false, error: 'invalid_oauth_hmac' });
  }

  return redirectToShopifyInstall(res, req, shop);
}

async function handleAuthCallback(req, res, url) {
  const shop = url.searchParams.get('shop');
  const code = url.searchParams.get('code');
  const state = url.searchParams.get('state');
  if (!validShopDomain(shop) || !code || !state) {
    return json(res, 400, { ok: false, error: 'missing_oauth_callback_params' });
  }
  if (!verifyOAuthHmac(url.searchParams, process.env.SHOPIFY_API_SECRET)) {
    return json(res, 401, { ok: false, error: 'invalid_oauth_hmac' });
  }
  if (!(await consumeOAuthState(state, shop))) {
    return json(res, 401, { ok: false, error: 'invalid_oauth_state' });
  }

  const token = await exchangeCodeForToken(shop, code);
  let webhook = null;
  const publicUrl = process.env.PUBLIC_APP_URL || process.env.APP_URL;
  if (publicUrl && !publicUrl.includes('example.com')) {
    webhook = await registerOrdersPaidWebhook({
      shop,
      uri: `${publicUrl.replace(/\/$/, '')}/webhooks/orders-paid`
    });
  }
  return html(res, 200, `
    <!doctype html>
    <meta charset="utf-8">
    <title>Blindbox App Installed</title>
    <body style="font-family: system-ui, sans-serif; padding: 32px;">
      <h1>Blindbox Draw Backend 已安装</h1>
      <p>店铺：${shop}</p>
      <p>权限：${token.scope || ''}</p>
      <p>付款 Webhook：${webhook ? '已创建' : '未创建，请先把 PUBLIC_APP_URL 换成真实域名后重新安装或手动创建'}</p>
      <p>现在可以关闭此页。下一步是部署后端并把 App Proxy / Webhook URL 改成真实域名。</p>
    </body>
  `);
}

async function handleVerify(req, res, url) {
  if (!appProxyAuthorized(req, url)) return json(res, 401, { ok: false, error: 'invalid_app_proxy_signature' });
  const orderName = url.searchParams.get('order');
  const email = url.searchParams.get('email');
  const credit = await getCredit(orderName, email);

  if (!credit || Number(credit.credits || 0) <= 0 || credit.used) {
    return json(res, 404, { ok: false, error: 'no_available_credit' });
  }

  return json(res, 200, {
    ok: true,
    orderName: credit.orderName,
    email: credit.email,
    credits: credit.credits
  });
}

async function handleConfirm(req, res, url) {
  if (!appProxyAuthorized(req, url)) return json(res, 401, { ok: false, error: 'invalid_app_proxy_signature' });
  const payload = JSON.parse((await readRawBody(req)).toString('utf8') || '{}');
  const { orderName, email, action, result } = payload;
  if (!orderName || !email || !action || !result) {
    return json(res, 400, { ok: false, error: 'missing_required_fields' });
  }

  const saved = await saveResult({ orderName, email, action, result });
  if (!saved.ok) return json(res, 409, saved);

  const order = await findOrderByNameAndEmail(orderName, email);
  if (!order || order.displayFinancialStatus !== 'PAID') {
    return json(res, 409, { ok: false, error: 'paid_order_not_found', savedLocally: true });
  }

  await tagOrder(order.id, ['blindbox-result', action === 'ship' ? 'blindbox-ship' : 'blindbox-decompose']);
  await setOrderMetafields(order.id, {
    draw_action: action,
    prize_tier: result.tier || '',
    prize_title: result.productTitle || result.title || '',
    prize_variant_id: result.variantId || '',
    prize_serial: result.serial || '',
    result_json: JSON.stringify(result).slice(0, 255)
  });

  let prizeOrder = null;
  if (process.env.CREATE_PRIZE_ORDER === 'true' && action === 'ship') {
    prizeOrder = await createPrizeOrder({ email, result, originalOrderName: orderName });
  }

  let smilePoints = null;
  if (action === 'decompose') {
    const points = Math.max(0, Math.trunc(Number(result.decomposablePoints || result.points || 0)));
    if (points > 0) {
      smilePoints = await adjustSmilePointsByEmail({
        email,
        pointsChange: points,
        description: `Blind box decompose +${points} points`,
        internalNote: `Blind box decompose from ${orderName}: ${result.productTitle || result.title || ''}`
      });
    }
  }

  return json(res, 200, {
    ok: true,
    message: 'blindbox_result_saved',
    orderId: order.id,
    prizeOrder,
    smilePoints
  });
}

async function handleSmilePoints(req, res, url) {
  if (!appProxyAuthorized(req, url)) return json(res, 401, { ok: false, error: 'invalid_app_proxy_signature' });
  const payload = JSON.parse((await readRawBody(req)).toString('utf8') || '{}');
  const email = payload.email;
  const pointsChange = Math.trunc(Number(payload.pointsChange || 0));
  if (!email || !pointsChange) {
    return json(res, 400, { ok: false, error: 'missing_email_or_points_change' });
  }
  if (Math.abs(pointsChange) > Number(process.env.SMILE_MAX_POINTS_ADJUSTMENT || 5000)) {
    return json(res, 400, { ok: false, error: 'points_change_too_large' });
  }
  const result = await adjustSmilePointsByEmail({
    email,
    pointsChange,
    description: payload.description || (pointsChange > 0 ? 'Blind box points credited' : 'Blind box points spent'),
    internalNote: payload.internalNote || 'Blind box storefront adjustment'
  });
  return json(res, result.ok ? 200 : 404, result);
}

async function route(req, res) {
  try {
    const url = new URL(req.url, `http://${req.headers.host}`);
    if (req.method === 'GET' && url.pathname === '/health') {
      return json(res, 200, { ok: true });
    }
    if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/auth')) {
      return handleAuth(req, res, url);
    }
    if (req.method === 'GET' && url.pathname === '/auth/callback') {
      return handleAuthCallback(req, res, url);
    }
    if (req.method === 'POST' && url.pathname === '/webhooks/orders-paid') {
      return handleOrdersPaid(req, res);
    }
    if (req.method === 'GET' && url.pathname === '/app-proxy/verify') {
      return handleVerify(req, res, url);
    }
    if (req.method === 'POST' && url.pathname === '/app-proxy/confirm-shipping') {
      return handleConfirm(req, res, url);
    }
    if (req.method === 'POST' && url.pathname === '/app-proxy/smile-points') {
      return handleSmilePoints(req, res, url);
    }
    return json(res, 404, { ok: false, error: 'not_found' });
  } catch (error) {
    console.error(error);
    return json(res, 500, { ok: false, error: error.message });
  }
}

http.createServer(route).listen(port, () => {
  console.log(`Blindbox Shopify app listening on http://localhost:${port}`);
});
