function discountEmailSubject(amount) {
  return `Your Jade Abyss $${amount} points reward code`;
}

function discountEmailHtml({ code, amount, pointsCost }) {
  return `
    <div style="font-family:Arial,sans-serif;line-height:1.6;color:#0f172a">
      <h2>Your Jade Abyss reward code is ready</h2>
      <p>You redeemed ${pointsCost} Glow points for a $${amount} discount.</p>
      <p style="font-size:22px;font-weight:800;letter-spacing:1px;padding:12px 16px;border:1px solid #cbd5e1;border-radius:10px;display:inline-block">${code}</p>
      <p>Use this code in the discount code box on the Shopify checkout page.</p>
      <p>This code is one-time use and only works for eligible products.</p>
    </div>
  `;
}

function discountEmailText({ code, amount, pointsCost }) {
  return [
    'Your Jade Abyss reward code is ready',
    '',
    `You redeemed ${pointsCost} Glow points for a $${amount} discount.`,
    `Discount code: ${code}`,
    '',
    'Use this code in the discount code box on the Shopify checkout page.',
    'This code is one-time use and only works for eligible products.'
  ].join('\n');
}

export async function sendDiscountCodeEmail({ email, code, amount, pointsCost }) {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.DISCOUNT_EMAIL_FROM || process.env.EMAIL_FROM;
  if (!apiKey || !from) {
    return { ok: false, skipped: true, reason: 'email_service_not_configured' };
  }

  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from,
      to: [email],
      subject: discountEmailSubject(amount),
      html: discountEmailHtml({ code, amount, pointsCost }),
      text: discountEmailText({ code, amount, pointsCost })
    })
  });

  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    return { ok: false, error: 'email_send_failed', status: response.status, body };
  }

  return { ok: true, provider: 'resend', id: body.id || '' };
}
