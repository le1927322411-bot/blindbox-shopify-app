import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

const dataDir = path.resolve('data');
const dbPath = path.join(dataDir, 'blindbox.json');

const emptyDb = {
  credits: {},
  results: {},
  oauthStates: {},
  shops: {}
};

async function readDb() {
  try {
    return JSON.parse(await readFile(dbPath, 'utf8'));
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    return structuredClone(emptyDb);
  }
}

async function writeDb(db) {
  await mkdir(dataDir, { recursive: true });
  await writeFile(dbPath, JSON.stringify(db, null, 2));
}

function orderKey(orderName, email) {
  return `${String(orderName || '').trim().toLowerCase()}::${String(email || '').trim().toLowerCase()}`;
}

export async function grantCredit({ orderId, orderName, email, credits = 1, source = 'orders_paid' }) {
  const db = await readDb();
  const key = orderKey(orderName, email);
  const existing = db.credits[key] || {};
  const nextCredits = Math.max(0, Number(existing.credits || 0)) + credits;
  db.credits[key] = {
    orderId,
    orderName,
    email,
    credits: nextCredits,
    used: nextCredits <= 0,
    source,
    updatedAt: new Date().toISOString(),
    createdAt: existing.createdAt || new Date().toISOString()
  };
  await writeDb(db);
  return db.credits[key];
}

export async function getCredit(orderName, email) {
  const db = await readDb();
  return db.credits[orderKey(orderName, email)] || null;
}

export async function saveResult({ orderName, email, result, action }) {
  const db = await readDb();
  const key = orderKey(orderName, email);
  const credit = db.credits[key];
  if (!credit) return { ok: false, error: 'credit_not_found' };
  if (Number(credit.credits || 0) <= 0) return { ok: false, error: 'no_credit' };

  credit.credits = Number(credit.credits || 0) - 1;
  credit.used = credit.credits <= 0;
  credit.usedAt = credit.used ? new Date().toISOString() : credit.usedAt;
  credit.result = result;
  credit.action = action;
  const resultKey = `${key}::${Date.now()}`;
  db.results[resultKey] = {
    orderName,
    email,
    result,
    action,
    createdAt: new Date().toISOString()
  };
  await writeDb(db);
  return { ok: true, credit, saved: db.results[resultKey] };
}

export async function saveOAuthState(state, shop) {
  const db = await readDb();
  db.oauthStates[state] = {
    shop,
    createdAt: new Date().toISOString(),
    expiresAt: Date.now() + 10 * 60 * 1000
  };
  await writeDb(db);
}

export async function consumeOAuthState(state, shop) {
  const db = await readDb();
  const saved = db.oauthStates[state];
  delete db.oauthStates[state];
  await writeDb(db);
  return Boolean(saved && saved.shop === shop && Number(saved.expiresAt) > Date.now());
}

export async function saveShopSession({ shop, accessToken, scope }) {
  const db = await readDb();
  db.shops[shop] = {
    shop,
    accessToken,
    scope,
    installedAt: new Date().toISOString()
  };
  await writeDb(db);
  return db.shops[shop];
}

export async function getShopSession(shop = process.env.SHOPIFY_SHOP_DOMAIN) {
  const db = await readDb();
  return db.shops[shop] || null;
}
