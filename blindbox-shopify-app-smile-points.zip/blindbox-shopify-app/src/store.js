import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';

const configuredDataDir = process.env.DATA_DIR ? path.resolve(process.env.DATA_DIR) : null;
const candidateDataDirs = [
  configuredDataDir,
  path.resolve('data'),
  path.resolve('/tmp/blindbox-data')
].filter(Boolean);

let activeDataDir = null;

async function getDataDir() {
  if (activeDataDir) return activeDataDir;

  let lastError;
  for (const candidate of candidateDataDirs) {
    try {
      await mkdir(candidate, { recursive: true });
      activeDataDir = candidate;
      return activeDataDir;
    } catch (error) {
      lastError = error;
    }
  }

  throw lastError;
}

async function getDbPath() {
  return path.join(await getDataDir(), 'blindbox.json');
}

const emptyDb = {
  credits: {},
  results: {},
  oauthStates: {},
  shops: {},
  dailyCheckins: {},
  webhookEvents: []
};

async function readDb() {
  try {
    return JSON.parse(await readFile(await getDbPath(), 'utf8'));
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    return structuredClone(emptyDb);
  }
}

async function writeDb(db) {
  await writeFile(await getDbPath(), JSON.stringify(db, null, 2));
}

function orderKey(orderName, email) {
  return `${String(orderName || '').trim().toLowerCase()}::${String(email || '').trim().toLowerCase()}`;
}

export async function grantCredit({ orderId, orderName, email, credits = 1, source = 'orders_paid' }) {
  const db = await readDb();
  const key = orderKey(orderName, email);
  const existing = db.credits[key] || {};
  const nextCredits = Math.max(0, Number(existing.credits || 0)) + credits;
  db.credits[key] = {
    orderId,
    orderName,
    email,
    credits: nextCredits,
    used: nextCredits <= 0,
    source,
    updatedAt: new Date().toISOString(),
    createdAt: existing.createdAt || new Date().toISOString()
  };
  await writeDb(db);
  return db.credits[key];
}

export async function getCredit(orderName, email) {
  const db = await readDb();
  return db.credits[orderKey(orderName, email)] || null;
}

export async function recordWebhookEvent(event) {
  const db = await readDb();
  db.webhookEvents ||= [];
  db.webhookEvents.unshift({
    ...event,
    createdAt: new Date().toISOString()
  });
  db.webhookEvents = db.webhookEvents.slice(0, 25);
  await writeDb(db);
  return db.webhookEvents[0];
}

export async function saveResult({ orderName, email, result, action }) {
  const db = await readDb();
  const key = orderKey(orderName, email);
  const credit = db.credits[key];
  if (!credit) return { ok: false, error: 'credit_not_found' };
  if (Number(credit.credits || 0) <= 0) return { ok: false, error: 'no_credit' };

  credit.credits = Number(credit.credits || 0) - 1;
  credit.used = credit.credits <= 0;
  credit.usedAt = credit.used ? new Date().toISOString() : credit.usedAt;
  credit.result = result;
  credit.action = action;
  const resultKey = `${key}::${Date.now()}`;
  db.results[resultKey] = {
    orderName,
    email,
    result,
    action,
    createdAt: new Date().toISOString()
  };
  await writeDb(db);
  return { ok: true, credit, saved: db.results[resultKey] };
}

export async function saveOAuthState(state, shop) {
  const db = await readDb();
  db.oauthStates[state] = {
    shop,
    createdAt: new Date().toISOString(),
    expiresAt: Date.now() + 10 * 60 * 1000
  };
  await writeDb(db);
}

export async function consumeOAuthState(state, shop) {
  const db = await readDb();
  const saved = db.oauthStates[state];
  delete db.oauthStates[state];
  await writeDb(db);
  return Boolean(saved && saved.shop === shop && Number(saved.expiresAt) > Date.now());
}

export async function saveShopSession({ shop, accessToken, scope }) {
  const db = await readDb();
  db.shops[shop] = {
    shop,
    accessToken,
    scope,
    installedAt: new Date().toISOString()
  };
  await writeDb(db);
  return db.shops[shop];
}

export async function getShopSession(shop = process.env.SHOPIFY_SHOP_DOMAIN) {
  const db = await readDb();
  return db.shops[shop] || null;
}

export async function getStoreStatus(shop = process.env.SHOPIFY_SHOP_DOMAIN) {
  const db = await readDb();
  const session = db.shops[shop] || null;
  const dataDir = await getDataDir();
  return {
    dataDir,
    configuredDataDir,
    dbPath: path.join(dataDir, 'blindbox.json'),
    hasShopSession: Boolean(session?.accessToken),
    shopSessionScope: session?.scope || '',
    shopSessionInstalledAt: session?.installedAt || '',
    creditKeys: Object.keys(db.credits || {}).length,
    dailyCheckinKeys: Object.keys(db.dailyCheckins || {}).length,
    recentWebhookEvents: (db.webhookEvents || []).slice(0, 5)
  };
}

function dailyCheckinKey(email, date) {
  return `${String(email || '').trim().toLowerCase()}::${date}`;
}

export async function reserveDailyCheckin({ email, date, points }) {
  const db = await readDb();
  db.dailyCheckins ||= {};
  const key = dailyCheckinKey(email, date);
  if (db.dailyCheckins[key]) {
    return { ok: false, error: 'already_checked_in_today', checkin: db.dailyCheckins[key] };
  }
  db.dailyCheckins[key] = {
    email,
    date,
    points,
    status: 'reserved',
    createdAt: new Date().toISOString()
  };
  await writeDb(db);
  return { ok: true, key, checkin: db.dailyCheckins[key] };
}

export async function completeDailyCheckin(key, extra = {}) {
  const db = await readDb();
  db.dailyCheckins ||= {};
  if (!db.dailyCheckins[key]) return null;
  db.dailyCheckins[key] = {
    ...db.dailyCheckins[key],
    ...extra,
    status: 'completed',
    completedAt: new Date().toISOString()
  };
  await writeDb(db);
  return db.dailyCheckins[key];
}

export async function releaseDailyCheckin(key, extra = {}) {
  const db = await readDb();
  db.dailyCheckins ||= {};
  if (db.dailyCheckins[key]?.status === 'reserved') {
    delete db.dailyCheckins[key];
  } else if (db.dailyCheckins[key]) {
    db.dailyCheckins[key] = {
      ...db.dailyCheckins[key],
      ...extra,
      status: 'failed',
      failedAt: new Date().toISOString()
    };
  }
  await writeDb(db);
}
