const smileApiBase = process.env.SMILE_API_BASE_URL || 'https://api.smile.io/v1';

function smileToken() {
  const token = process.env.SMILE_API_TOKEN || process.env.SMILE_ACCESS_TOKEN;
  if (!token) throw new Error('Missing SMILE_API_TOKEN');
  return token;
}

async function smileRequest(path, options = {}) {
  const response = await fetch(`${smileApiBase}${path}`, {
    ...options,
    headers: {
      'Authorization': `Bearer ${smileToken()}`,
      'Content-Type': 'application/json',
      'Accept': 'application/json',
      ...(options.headers || {})
    }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = body?.error?.message || body?.message || JSON.stringify(body);
    throw new Error(`Smile API error ${response.status}: ${message}`);
  }
  return body;
}

export async function findSmileCustomerByEmail(email) {
  const cleanEmail = String(email || '').trim().toLowerCase();
  if (!cleanEmail) throw new Error('Missing customer email');
  const params = new URLSearchParams({ email: cleanEmail, limit: '1' });
  const data = await smileRequest(`/customers?${params.toString()}`, { method: 'GET' });
  return (data.customers || []).find((customer) => {
    return String(customer.email || '').toLowerCase() === cleanEmail;
  }) || null;
}

export async function adjustSmilePointsByEmail({ email, pointsChange, description, internalNote }) {
  const customer = await findSmileCustomerByEmail(email);
  if (!customer) {
    return { ok: false, error: 'smile_customer_not_found' };
  }
  const change = Math.trunc(Number(pointsChange || 0));
  if (!change) {
    return { ok: false, error: 'invalid_points_change' };
  }
  if (change < 0 && Number(customer.points_balance || 0) + change < 0) {
    return { ok: false, error: 'insufficient_smile_points', customer };
  }
  const data = await smileRequest('/points_transactions', {
    method: 'POST',
    body: JSON.stringify({
      points_transaction: {
        customer_id: customer.id,
        points_change: change,
        description: description || (change > 0 ? 'Blind box points credited' : 'Blind box points spent'),
        internal_note: internalNote || ''
      }
    })
  });
  return {
    ok: true,
    customer,
    pointsTransaction: data.points_transaction
  };
}
