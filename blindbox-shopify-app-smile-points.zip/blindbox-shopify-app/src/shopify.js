import { getShopSession } from './store.js';

const apiVersion = process.env.SHOPIFY_API_VERSION || '2026-04';

function shopifyEndpoint(shop = process.env.SHOPIFY_SHOP_DOMAIN) {
  if (!shop) throw new Error('Missing SHOPIFY_SHOP_DOMAIN');
  return `https://${shop}/admin/api/${apiVersion}/graphql.json`;
}

export async function adminGraphql(query, variables = {}, shop = process.env.SHOPIFY_SHOP_DOMAIN) {
  const session = await getShopSession(shop);
  const token = session?.accessToken || process.env.SHOPIFY_ADMIN_ACCESS_TOKEN;
  if (!token || token === 'shpat_xxx') throw new Error('Missing Shopify Admin access token. Install the app first.');

  const response = await fetch(shopifyEndpoint(shop), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-Shopify-Access-Token': token
    },
    body: JSON.stringify({ query, variables })
  });

  const json = await response.json();
  if (!response.ok || json.errors) {
    throw new Error(JSON.stringify(json.errors || json, null, 2));
  }
  return json.data;
}

export async function findOrderByNameAndEmail(orderName, email) {
  const query = `
    query FindOrder($query: String!) {
      orders(first: 5, query: $query) {
        nodes {
          id
          name
          email
          displayFinancialStatus
          tags
        }
      }
    }
  `;
  const cleanName = String(orderName || '').trim();
  const cleanEmail = String(email || '').trim();
  const data = await adminGraphql(query, {
    query: `name:${cleanName} email:${cleanEmail}`
  });
  return data.orders.nodes.find((order) => {
    return order.name === cleanName && String(order.email || '').toLowerCase() === cleanEmail.toLowerCase();
  }) || null;
}

export async function findCustomerEmailById(customerId) {
  const numericId = String(customerId || '').trim();
  if (!numericId) return '';

  const query = `
    query FindCustomer($id: ID!) {
      customer(id: $id) {
        id
        email
      }
    }
  `;
  const data = await adminGraphql(query, {
    id: numericId.startsWith('gid://') ? numericId : `gid://shopify/Customer/${numericId}`
  });
  return String(data.customer?.email || '').trim().toLowerCase();
}

function customerEmailQuery(email) {
  const clean = String(email || '').trim().toLowerCase();
  return `email:${clean.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}`;
}

export async function findCustomerByEmail(email) {
  const cleanEmail = String(email || '').trim().toLowerCase();
  if (!cleanEmail) return null;

  const query = `
    query FindCustomerByEmail($query: String!) {
      customers(first: 1, query: $query) {
        nodes {
          id
          email
          dailyCheckin: metafield(namespace: "blindbox", key: "last_daily_checkin_date") {
            id
            value
          }
        }
      }
    }
  `;
  const data = await adminGraphql(query, { query: customerEmailQuery(cleanEmail) });
  return data.customers.nodes.find((customer) => {
    return String(customer.email || '').trim().toLowerCase() === cleanEmail;
  }) || null;
}

export async function setCustomerMetafields(customerId, values) {
  const metafields = Object.entries(values).map(([key, value]) => ({
    ownerId: customerId,
    namespace: 'blindbox',
    key,
    type: 'single_line_text_field',
    value: String(value ?? '')
  }));
  const query = `
    mutation CustomerMetafieldsSet($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) {
        metafields { id key namespace value }
        userErrors { field message code }
      }
    }
  `;
  const data = await adminGraphql(query, { metafields });
  const errors = data.metafieldsSet.userErrors || [];
  if (errors.length) throw new Error(JSON.stringify(errors));
  return data.metafieldsSet.metafields;
}

export async function tagOrder(orderId, tags) {
  const query = `
    mutation TagsAdd($id: ID!, $tags: [String!]!) {
      tagsAdd(id: $id, tags: $tags) {
        node { id }
        userErrors { field message }
      }
    }
  `;
  const data = await adminGraphql(query, { id: orderId, tags });
  const errors = data.tagsAdd.userErrors || [];
  if (errors.length) throw new Error(JSON.stringify(errors));
}

export async function setOrderMetafields(orderId, values) {
  const metafields = Object.entries(values).map(([key, value]) => ({
    ownerId: orderId,
    namespace: 'blindbox',
    key,
    type: 'single_line_text_field',
    value: String(value ?? '')
  }));
  const query = `
    mutation MetafieldsSet($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) {
        metafields { id key namespace value }
        userErrors { field message code }
      }
    }
  `;
  const data = await adminGraphql(query, { metafields });
  const errors = data.metafieldsSet.userErrors || [];
  if (errors.length) throw new Error(JSON.stringify(errors));
  return data.metafieldsSet.metafields;
}

export async function createPrizeOrder({ email, result, originalOrderName }) {
  const title = result?.productTitle || result?.title || 'Blind box prize';
  const query = `
    mutation OrderCreate($order: OrderCreateOrderInput!) {
      orderCreate(order: $order) {
        order { id name }
        userErrors { field message }
      }
    }
  `;
  const data = await adminGraphql(query, {
    order: {
      email,
      financialStatus: 'PAID',
      tags: ['blindbox-prize', `source:${originalOrderName}`],
      note: `Blind box prize for ${originalOrderName}: ${title}`,
      lineItems: [
        {
          title,
          priceSet: {
            shopMoney: {
              amount: '0.00',
              currencyCode: 'USD'
            }
          },
          quantity: 1,
          requiresShipping: true
        }
      ],
      metafields: [
        {
          namespace: 'blindbox',
          key: 'source_order',
          type: 'single_line_text_field',
          value: originalOrderName
        },
        {
          namespace: 'blindbox',
          key: 'prize_result',
          type: 'single_line_text_field',
          value: JSON.stringify(result).slice(0, 255)
        }
      ]
    }
  });
  const errors = data.orderCreate.userErrors || [];
  if (errors.length) throw new Error(JSON.stringify(errors));
  return data.orderCreate.order;
}

function randomDiscountCode(prefix = 'JADE') {
  const token = Math.random().toString(36).slice(2, 8).toUpperCase();
  const stamp = Date.now().toString(36).slice(-5).toUpperCase();
  return `${prefix}-${stamp}-${token}`;
}

function splitConfiguredIds(value) {
  return String(value || '')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean);
}

function normalizeShopifyGid(value, type) {
  const clean = String(value || '').trim();
  if (!clean) return '';
  if (clean.startsWith('gid://shopify/')) return clean;
  return `gid://shopify/${type}/${clean}`;
}

function splitConfiguredHandles(value) {
  return String(value || 'normal,premium,hidden,limited')
    .split(',')
    .map((item) => item.trim().replace(/^\/+|\/+$/g, '').replace(/^collections\//, ''))
    .filter(Boolean);
}

async function findCollectionIdsByHandles(handles) {
  const cleanHandles = [...new Set((handles || []).map((handle) => String(handle || '').trim()).filter(Boolean))];
  if (!cleanHandles.length) return [];

  const query = `
    query FindCollectionsByHandle($query: String!) {
      collections(first: 1, query: $query) {
        nodes {
          id
          handle
        }
      }
    }
  `;
  const foundIds = [];
  for (const handle of cleanHandles) {
    const data = await adminGraphql(query, { query: `handle:${handle}` });
    const collection = (data.collections?.nodes || []).find((node) => node.handle === handle);
    if (collection?.id) foundIds.push(collection.id);
  }
  return foundIds;
}

async function discountEligibleItemsInput() {
  const collectionIds = splitConfiguredIds(process.env.POINTS_DISCOUNT_COLLECTION_IDS)
    .map((id) => normalizeShopifyGid(id, 'Collection'));
  if (collectionIds.length) {
    return {
      collections: {
        add: collectionIds
      }
    };
  }

  const productIds = splitConfiguredIds(process.env.POINTS_DISCOUNT_PRODUCT_IDS)
    .map((id) => normalizeShopifyGid(id, 'Product'));
  if (productIds.length) {
    return {
      products: {
        productsToAdd: productIds
      }
    };
  }

  const defaultCollectionIds = await findCollectionIdsByHandles(
    splitConfiguredHandles(process.env.POINTS_DISCOUNT_COLLECTION_HANDLES)
  );
  if (defaultCollectionIds.length) {
    return {
      collections: {
        add: defaultCollectionIds
      }
    };
  }

  throw new Error('missing_points_discount_eligible_collections');
}

export async function createOneTimeAmountDiscount({ email, pointsCost, amount }) {
  const discountAmount = Number(amount || 0);
  if (!discountAmount || discountAmount <= 0) throw new Error('invalid_discount_amount');

  const code = randomDiscountCode(`JADE${Math.trunc(discountAmount)}`);
  const titleEmail = String(email || '').trim().toLowerCase();
  const title = `Jade Abyss points reward ${pointsCost} points = $${discountAmount} off${titleEmail ? ` (${titleEmail})` : ''}`;
  const startsAt = new Date().toISOString();

  const query = `
    mutation DiscountCodeBasicCreate($basicCodeDiscount: DiscountCodeBasicInput!) {
      discountCodeBasicCreate(basicCodeDiscount: $basicCodeDiscount) {
        codeDiscountNode {
          id
          codeDiscount {
            ... on DiscountCodeBasic {
              title
              codes(first: 1) {
                nodes { code }
              }
            }
          }
        }
        userErrors { field code message }
      }
    }
  `;
  const data = await adminGraphql(query, {
    basicCodeDiscount: {
      title,
      code,
      startsAt,
      customerSelection: { all: true },
      customerGets: {
        value: {
          discountAmount: {
            amount: String(discountAmount.toFixed(2)),
            appliesOnEachItem: false
          }
        },
        items: await discountEligibleItemsInput()
      },
      usageLimit: 1,
      appliesOncePerCustomer: true
    }
  });
  const created = data.discountCodeBasicCreate;
  const errors = created.userErrors || [];
  if (errors.length) throw new Error(JSON.stringify(errors));
  const returnedCode = created.codeDiscountNode?.codeDiscount?.codes?.nodes?.[0]?.code || code;
  return {
    id: created.codeDiscountNode?.id,
    code: returnedCode,
    title,
    amount: discountAmount,
    pointsCost
  };
}

export async function registerOrdersPaidWebhook({ shop = process.env.SHOPIFY_SHOP_DOMAIN, uri }) {
  const query = `
    mutation WebhookSubscriptionCreate($topic: WebhookSubscriptionTopic!, $webhookSubscription: WebhookSubscriptionInput!) {
      webhookSubscriptionCreate(topic: $topic, webhookSubscription: $webhookSubscription) {
        webhookSubscription { id topic uri }
        userErrors { field message }
      }
    }
  `;
  const data = await adminGraphql(query, {
    topic: 'ORDERS_PAID',
    webhookSubscription: {
      uri,
      format: 'JSON'
    }
  }, shop);
  const errors = data.webhookSubscriptionCreate.userErrors || [];
  if (errors.some((error) => String(error.message || '').includes('already been taken'))) {
    return { id: 'existing', topic: 'ORDERS_PAID', uri };
  }
  if (errors.length) throw new Error(JSON.stringify(errors));
  return data.webhookSubscriptionCreate.webhookSubscription;
}
