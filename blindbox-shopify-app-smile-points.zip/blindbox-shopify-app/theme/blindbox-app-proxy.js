/*
  Replace the old contact-form submission in your theme with this pattern.
  App Proxy URL in Shopify should map:
    Storefront: /apps/blindbox/*
    App server: /app-proxy/*
*/

async function verifyCashDraw(orderName, email) {
  const url = `/apps/blindbox/verify?order=${encodeURIComponent(orderName)}&email=${encodeURIComponent(email)}`;
  const response = await fetch(url, { headers: { Accept: 'application/json' } });
  return response.json();
}

async function confirmBlindboxResult({ orderName, email, action, result }) {
  const response = await fetch('/apps/blindbox/confirm-shipping', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json'
    },
    body: JSON.stringify({ orderName, email, action, result })
  });
  return response.json();
}

window.blindboxAppProxy = {
  verifyCashDraw,
  confirmBlindboxResult
};
