# Blindbox Shopify App Backend

This is a minimal backend for a Shopify blind-box flow.

It does three jobs:

1. Receives Shopify `orders/paid` webhooks.
2. Grants one cash draw credit when the paid order contains the cash blind box product.
3. Receives the draw result from the storefront and writes it back to the paid Shopify order with tags and metafields.
4. Optionally adjusts Smile points for points draws and decomposed prizes.

## Setup

Copy the environment file:

```bash
cp .env.example .env
```

Fill these values:

- `SHOPIFY_SHOP_DOMAIN`
- `SHOPIFY_CLIENT_ID`
- `SHOPIFY_API_SECRET`
- `PUBLIC_APP_URL` after deployment
- `CASH_PRODUCT_TITLE_KEYWORD` or `CASH_PRODUCT_ID` / `CASH_VARIANT_ID`
- `SMILE_API_TOKEN` if points draw spending or decomposed-prize points should write into Smile

Run locally:

```bash
npm run dev
```

Health check:

```bash
curl http://localhost:8787/health
```

## Shopify App Setup

Create an app in the Shopify Dev Dashboard:

1. App name: `Blindbox Draw Backend`.
2. Access scopes: `read_orders,write_orders`.
3. App URL: `https://api.jadeabyss.com/auth`.
4. Redirect URL: `https://api.jadeabyss.com/auth/callback`.
5. App Proxy:
   - Subpath prefix: `apps`
   - Subpath: `blindbox`
   - Proxy URL: `https://api.jadeabyss.com/app-proxy`
6. Copy the client ID into `SHOPIFY_CLIENT_ID`.
7. Copy the client secret into `SHOPIFY_API_SECRET`.
8. Open `https://api.jadeabyss.com/auth?shop=ht60wm-np.myshopify.com` to install the app. The OAuth callback stores the offline Admin API token locally.

## Webhook

After OAuth install, the backend tries to create this webhook automatically when `PUBLIC_APP_URL` is a real domain:

- Event: `orders/paid`
- URL: `https://api.jadeabyss.com/webhooks/orders-paid`
- Format: JSON

If auto-registration fails, create the webhook manually with the same URL.

When a paid order contains the cash blind box product, the app stores:

```json
{
  "orderName": "#1001",
  "email": "customer@example.com",
  "credits": 1
}
```

## App Proxy

In your Shopify app proxy settings, configure:

- Subpath prefix: `apps`
- Subpath: `blindbox`
- Proxy URL: `https://your-app-domain.com/app-proxy`

Then storefront URLs become:

- `/apps/blindbox/verify`
- `/apps/blindbox/confirm-shipping`
- `/apps/blindbox/smile-points`

## Theme Integration

Your theme should stop submitting the hidden Shopify contact form. That form causes `缺少验证码令牌`.

Instead:

1. On "验证订单，解锁 1 次抽奖", call:

```js
window.blindboxAppProxy.verifyCashDraw(orderName, email)
```

2. On "确认发货", call:

```js
window.blindboxAppProxy.confirmBlindboxResult({
  orderName,
  email,
  action: 'ship',
  result: {
    tier: '普通款',
    productTitle: 'Aquamarine Crystal Bracelet',
    variantId: 'gid://shopify/ProductVariant/...',
    serial: ''
  }
})
```

3. On "分解成积分", call the same endpoint with:

```js
action: 'decompose'
```

For the newer Smile-integrated theme, points draw spend and decompose credit call:

```text
POST /apps/blindbox/smile-points
```

The backend finds the Smile customer by email and creates a Smile points transaction. Keep `SMILE_API_TOKEN` only on the backend; never put it in theme JavaScript.

## Why Not Contact Form?

Shopify contact forms require anti-spam captcha tokens. Programmatically submitting a hidden contact form will fail with:

```text
缺少验证码令牌
```

Use App Proxy + Admin API instead.

## Notes

By default this app writes tags and metafields to the original paid order. That is safer than creating fake paid orders.

If you really want a separate prize order, set:

```bash
CREATE_PRIZE_ORDER=true
```

Then review the created order behavior carefully before using it in production.

Smile API access may require a Smile plan that includes API access. If `SMILE_API_TOKEN` is missing or the Smile customer email is not found, the storefront will show an error instead of using local/demo points.
