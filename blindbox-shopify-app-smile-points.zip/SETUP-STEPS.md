# Shopify Setup Steps

## 1. Dev Dashboard App

You already created:

- App: `Blindbox Draw Backend`
- Scopes: `read_orders,write_orders`
- App proxy: `/apps/blindbox`
- Active version: `blindbox-draw-backend-2`

Use a backend subdomain. Do not use `jadeabyss.com` or `www.jadeabyss.com`; those are already connected to the Shopify storefront.

- App URL: `https://api.jadeabyss.com/auth`
- Redirect URL: `https://api.jadeabyss.com/auth/callback`
- App Proxy URL: `https://api.jadeabyss.com/app-proxy`

## 2. Backend Environment

Set these on the deployed backend:

```text
PUBLIC_APP_URL=https://api.jadeabyss.com
SHOPIFY_SHOP_DOMAIN=ht60wm-np.myshopify.com
SHOPIFY_CLIENT_ID=524c9385d49b28503b3c26cf247b3655
SHOPIFY_SCOPES=read_orders,write_orders
SHOPIFY_API_SECRET=the-client-secret-from-dev-dashboard
CASH_PRODUCT_TITLE_KEYWORD=现金盲盒
CREATE_PRIZE_ORDER=false
```

`SHOPIFY_ADMIN_ACCESS_TOKEN` can stay as `shpat_xxx`; OAuth will store the real token after install.

## 3. Deploy the Backend

The backend must have a public HTTPS URL for OAuth, Shopify webhooks, and App Proxy.

Good simple choices:

- Render Web Service
- Railway
- Fly.io
- VPS

Start command:

```bash
npm start
```

This repo also includes:

- `Dockerfile`
- `render.yaml`

If using Render, create a Web Service from this folder and add a persistent disk mounted at `/app/data`.

Environment variables:

Copy everything from `.env`, but use the real token and secret.

Health URL should return `{"ok":true`:

```text
https://api.jadeabyss.com/health
```

## 4. Install the App

Open this URL in your browser after deployment:

```text
https://api.jadeabyss.com/auth?shop=ht60wm-np.myshopify.com
```

Approve the Shopify permission screen. The app stores the offline Admin API token and tries to create the `ORDERS_PAID` webhook automatically.

## 5. Webhook

If automatic webhook creation fails, create it manually:

- Event/topic: `orders/paid`
- Format: JSON
- URL: `https://api.jadeabyss.com/webhooks/orders-paid`

Storefront endpoint examples:

```text
/apps/blindbox/verify
/apps/blindbox/confirm-shipping
```

## 5. Theme Change

Stop submitting the hidden Shopify contact form. That is why you saw:

```text
缺少验证码令牌
```

Use `theme/blindbox-app-proxy.js` as the theme-side pattern.
